###
# #%L
# example::Pipelines::Machine Learning Pipeline::Pipeline Training
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
"""
Base implementation of this pipeline.

GENERATED CODE - DO NOT MODIFY (add your customizations in MachineLearningPipeline).

Generated from: templates/general-mlflow/training.base.py.vm
"""
import sys

if sys.version_info[0:3] < (3, 9, 1):
    print("\n")
    print("====================================")
    print("== ERROR: Please use Python >= 3.9.1 ==")
    print("====================================")
    sys.exit(1)

from abc import ABC, abstractmethod
from typing import List, NamedTuple
from pandas import DataFrame
from ..config.pipeline_config import PipelineConfig
from aiops_core_bom.training_bom import TrainingBOM
from datetime import datetime
import mlflow
import json
from aiops_security.pdp_client import PDPClient
from aiopsauth.auth_config import AuthConfig
from pathlib import Path


class DatasetSplits(NamedTuple):
    """
    Class to store the training and test splits of a dataset.
    The splits are of type any, to allow for custom implementation
    for handling any number of datasets per split.
    """

    train: any
    test: any


class MachineLearningPipelineBase(ABC):
    """
    Base implementation of the pipeline.
    """

    def __init__(self, experiment_name):
        """
        Default initializations for the pipeline.
        """
        # set default mlflow configurations
        self.config = PipelineConfig()
        mlflow.set_tracking_uri(self.config.mlflow_tracking_uri())
        mlflow.set_experiment(experiment_name)

    @abstractmethod
    def load_dataset(self) -> DataFrame:
        """
        Method to load a dataset for training.
        Returns a dataset of type DataFrame.
        """
        pass

    @abstractmethod
    def prep_dataset(self, dataset: DataFrame) -> DataFrame:
        """
        Method to perform last-mile data preparation on the loaded dataset.
        Returns the prepped dataset.
        """
        pass

    @abstractmethod
    def select_features(self, dataset: DataFrame) -> List[str]:
        """
        Method to perform feature selection on the prepped dataset.
        Returns a list of the features (columns) selected from the dataset.
        """
        pass

    @abstractmethod
    def split_dataset(self, dataset: DataFrame) -> DatasetSplits:
        """
        Method to create the train and test splits on the dataset with selected features.
        Returns the splits within a DatasetSplits object.
        """
        pass

    @abstractmethod
    def train_model(self, train_dataset: any) -> any:
        """
        Method to train a model with the training dataset split(s).
        Returns the model that has been trained.
        """
        pass

    @abstractmethod
    def evaluate_model(self, model: any, test_dataset: any) -> float:
        """
        Method to evaluate the trained model with the test dataset split(s).
        Returns the score of the model evaluation.
        """
        pass

    @abstractmethod
    def save_model(self, model: any) -> None:
        """
        Method to save the model to a location.
        """
        pass

    @abstractmethod
    def deploy_model(self, score: float, model: any) -> None:
        """
        Method to deploy the model if needed.
        """
        pass

    def run(self):
        """
        Runs the pipeline.
        """
        print("Running %s..." % type(self).__name__)

        with mlflow.start_run() as run:
            start = datetime.now()

            self.training_run_id = mlflow.active_run().info.run_uuid
            loaded_dataset = self.load_dataset()
            prepped_dataset = self.prep_dataset(loaded_dataset)
            features = self.select_features(prepped_dataset)
            splits = self.split_dataset(prepped_dataset[features])
            model = self.train_model(splits.train)
            score = self.evaluate_model(model, splits.test)
            self.save_model(model)
            self.deploy_model(score, model)

            end = datetime.now()

            self.create_training_bom(
                self.training_run_id, start, end, loaded_dataset, features
            )

        print(type(self).__name__, "complete")

    def set_dataset_origin(self, origin: str) -> None:
        """
        Sets the origin of the dataset for a training run.
        """
        if not origin:
            print("WARNING: no value given for dataset origin!")

        self.dataset_origin = origin

    def set_model_information(self, model_type: str, model_architecture: str) -> None:
        """
        Sets the model information for a training run.
        """
        if not model_type:
            print("WARNING: no value given for model type!")
        if not model_architecture:
            print("WARNING: no value given for model architecture!")

        self.model_type = model_type
        self.model_architecture = model_architecture

    def create_training_bom(
        self,
        run_id: str,
        start: datetime,
        end: datetime,
        loaded_dataset: DataFrame,
        selected_features: List[str],
    ) -> None:
        """
        Creates a Bill of Materials for a training run.
        """
        try:
            run = mlflow.get_run(run_id=run_id)
            dataset_info = TrainingBOM.DatasetInfo(
                origin=self.dataset_origin, size=len(loaded_dataset)
            )
            feature_info = TrainingBOM.FeatureInfo(
                original_features=list(loaded_dataset),
                selected_features=selected_features,
            )
            model_info = TrainingBOM.ModelInfo(
                type=self.model_type, architecture=self.model_architecture
            )

            training_bom = TrainingBOM(
                id=run_id,
                start_time=str(start),
                end_time=str(end),
                mlflow_params=run.data.params,
                mlflow_metrics=run.data.metrics,
                dataset_info=dataset_info,
                feature_info=feature_info,
                model_info=model_info,
            )

            with open(
                "/notebooks/boms/" + run_id + "-training-bom.json", "w"
            ) as output_json:
                json.dump(training_bom.dict(), output_json)

        except Exception as e:
            print("Error creating Bill of Materials for training run: " + str(e))

    def authorize(self, token: str, action: str):
        """
        Calls the Policy Decision Point server to authorize a jwt
        """

        auth_config = AuthConfig()

        pdp_client = PDPClient(auth_config.pdp_host_url())

        decision = pdp_client.authorize(token, "", action)

        return decision

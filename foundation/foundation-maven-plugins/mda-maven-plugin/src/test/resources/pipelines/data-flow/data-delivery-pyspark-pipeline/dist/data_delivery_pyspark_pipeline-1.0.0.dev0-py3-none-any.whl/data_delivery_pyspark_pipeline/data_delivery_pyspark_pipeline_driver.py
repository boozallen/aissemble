###
# #%L
# test::Pipelines::Data Delivery Pyspark Pipeline
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from data_delivery_pyspark_pipeline.step.example_step import ExampleStep
from krausening.logging import LogManager

"""
Driver to run the DataDeliveryPysparkPipeline.

GENERATED STUB CODE - PLEASE ***DO*** MODIFY

Originally generated from: templates/data-delivery-pyspark/pipeline.driver.py.vm 
"""

logger = LogManager.get_instance().get_logger("DataDeliveryPysparkPipeline")


if __name__ == "__main__":
    logger.info("STARTED: DataDeliveryPysparkPipeline driver")

    # TODO: Execute steps in desired order and handle any inbound and outbound types
    ExampleStep().execute_step()

###
# #%L
# example::Pipelines::Pyspark Pipeline
# %%
# Copyright (C) 2021 Booz Allen
# %%
# This software package is licensed under the Booz Allen Public License. All Rights Reserved.
# #L%
###
from ...generated.step.abstract_data_action import AbstractDataAction
from krausening.logging import LogManager
from abc import abstractmethod
from time import time_ns
from aiops_security.pdp_client import PDPClient
from aiopsauth.json_web_token_util import AiopsSecurityException
from aiopsauth.auth_config import AuthConfig
from pathlib import Path
from policy_manager.configuration import PolicyConfiguration
from aiops_encrypt_policy import DataEncryptionPolicy, DataEncryptionPolicyManager
import os
from typing import List


class ExampleStepBase(AbstractDataAction):
    """
    Performs scaffolding synchronous processing for ExampleStep. Business logic is delegated to the subclass.

    GENERATED CODE - DO NOT MODIFY (add your customizations in ExampleStep).

    Generated from: templates/data-delivery-pyspark/synchronous.processor.base.py.vm
    """

    logger = LogManager.get_instance().get_logger("ExampleStepBase")
    step_phase = "ExampleStep"
    bomIdentifier = "Unspecified ExampleStep BOM identifier"

    def __init__(self, data_action_type, descriptive_label):
        super().__init__(data_action_type, descriptive_label)

    def execute_step(self) -> None:
        """
        Executes this step.
        """
        start = time_ns()
        ExampleStepBase.logger.info("START: step execution...")

        self.execute_step_impl()

        stop = time_ns()
        ExampleStepBase.logger.info(
            "COMPLETE: step execution completed in %sms" % ((stop - start) / 1000000)
        )

    @abstractmethod
    def execute_step_impl(self) -> None:
        """
        This method performs the business logic of this step,
        and should be implemented in ExampleStep.
        """
        pass

    def authorize(self, token: str, action: str):
        """
        Calls the Policy Decision Point server to authorize a jwt
        """
        auth_config = AuthConfig()

        if auth_config.is_authorization_enabled():
            pdp_client = PDPClient(auth_config.pdp_host_url())
            decision = pdp_client.authorize(token, "", action)

            if "PERMIT" == decision:
                ExampleStepBase.logger.info("User is authorized to run ExampleStep")
            else:
                raise AiopsSecurityException("User is not authorized")

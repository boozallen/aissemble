###
# #%L
# example::Pipelines::Pyspark Pipeline
# %%
# Copyright (C) 2021 Booz Allen
# %%
# This software package is licensed under the Booz Allen Public License. All Rights Reserved.
# #L%
###
from abc import ABC
from pyspark.sql import SparkSession
from krausening.properties import PropertyManager


class AbstractDataAction(ABC):
    """
    Contains the general concepts needed to perform a base AIOps Reference Architecture Data Action.
    A Data Action is a step within a Data Flow.

    GENERATED CODE - DO NOT MODIFY (add your customizations in the step implementations).

    Generated from: templates/data-delivery-pyspark/abstract.data.action.py.vm
    """

    def __init__(self, data_action_type, descriptive_label):
        self.data_action_type = data_action_type
        self.descriptive_label = descriptive_label

        self.spark = self.create_spark_session("PysparkPipeline")
        self.tailor_spark_logging_levels(self.spark)

    def create_spark_session(self, app_name: str) -> SparkSession:
        properties = PropertyManager.get_instance().get_properties(
            "spark-data-delivery.properties"
        )
        builder = SparkSession.builder
        if properties.getProperty("execution.mode.legacy", "false") == "true":
            builder = builder.master("local[*]").config(
                "spark.driver.host", "localhost"
            )
        return builder.getOrCreate()

    def tailor_spark_logging_levels(self, spark: SparkSession) -> None:
        """
        Allows Spark logging levels to be tailored to prevent excessive logging.
        Override this method if needed.
        """
        logger = spark._jvm.org.apache.log4j
        logger.LogManager.getRootLogger().setLevel(logger.Level.WARN)
        logger.LogManager.getLogger("org.apache.spark.sql").setLevel(logger.Level.ERROR)

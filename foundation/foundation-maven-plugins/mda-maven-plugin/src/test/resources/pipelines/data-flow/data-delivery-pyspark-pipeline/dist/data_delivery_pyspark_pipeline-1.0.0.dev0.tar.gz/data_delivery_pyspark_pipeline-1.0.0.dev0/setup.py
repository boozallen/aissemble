# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['pyspark_pipeline',
 'pyspark_pipeline.generated',
 'pyspark_pipeline.generated.step',
 'pyspark_pipeline.step']

package_data = \
{'': ['*'], 'pyspark_pipeline': ['resources/apps/*']}

install_requires = \
['extensions-encryption-vault-python>=0.12.0.dev,<0.13.0',
 'foundation-core-python>=0.12.0.dev,<0.13.0',
 'foundation-encryption-policy-python>=0.12.0.dev,<0.13.0',
 'foundation-feature-serving-python>=0.12.0.dev,<0.13.0',
 'foundation-pdp-client-python>=0.12.0.dev,<0.13.0',
 'jsonpickle>=2.1.0,<3.0.0',
 'krausening>=14',
 'pyspark==3.2.2',
 'pyyaml>=6.0,<7.0']

setup_kwargs = {
    'name': 'pyspark-pipeline',
    'version': '1.0.0.dev0',
    'description': 'Description of package',
    'long_description': 'None',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9.9,<4.0.0',
}


setup(**setup_kwargs)

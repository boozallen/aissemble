###
# #%L
# test::Pipelines::Data Delivery Pyspark Pipeline
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from ...generated.step.abstract_data_action import AbstractDataAction
from krausening.logging import LogManager
from abc import abstractmethod
from time import time_ns
from pathlib import Path
from policy_manager.configuration import PolicyConfiguration
from aiops_encrypt_policy import DataEncryptionPolicy, DataEncryptionPolicyManager
import os
from typing import List


class ExampleStepBase(AbstractDataAction):
    """
    Performs scaffolding synchronous processing for ExampleStep. Business logic is delegated to the subclass.

    GENERATED CODE - DO NOT MODIFY (add your customizations in ExampleStep).

    Generated from: templates/data-delivery-pyspark/synchronous.processor.base.py.vm
    """

    logger = LogManager.get_instance().get_logger("ExampleStepBase")
    step_phase = "ExampleStep"
    bomIdentifier = "Unspecified ExampleStep BOM identifier"

    def __init__(self, data_action_type, descriptive_label):
        super().__init__(data_action_type, descriptive_label)

    def execute_step(self) -> None:
        """
        Executes this step.
        """
        start = time_ns()
        ExampleStepBase.logger.info("START: step execution...")

        self.execute_step_impl()

        stop = time_ns()
        ExampleStepBase.logger.info(
            "COMPLETE: step execution completed in %sms" % ((stop - start) / 1000000)
        )

    @abstractmethod
    def execute_step_impl(self) -> None:
        """
        This method performs the business logic of this step,
        and should be implemented in ExampleStep.
        """
        pass

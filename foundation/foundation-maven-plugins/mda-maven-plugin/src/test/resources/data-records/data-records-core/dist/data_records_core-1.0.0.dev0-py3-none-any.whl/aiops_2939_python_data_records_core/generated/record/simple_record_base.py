###
# #%L
# Python Pipeline::Shared::Data Records Core
# %%
# Copyright (C) 2021 Booz Allen
# %%
# All Rights Reserved. You may not copy, reproduce, distribute, publish, display,
# execute, modify, create derivative works of, transmit, sell or offer for resale,
# or in any way exploit any part of this solution without Booz Allen Hamilton’s
# express written permission.
# #L%
###
from abc import ABC
from .simple_record_field import SimpleRecordField
from typing import Any, Dict
import jsonpickle


class SimpleRecordBase(ABC):
    """
    Base implementation of the Record for SimpleRecord.

    GENERATED CODE - DO NOT MODIFY (add your customizations in SimpleRecord).

    Generated from: templates/data-delivery-data-records/record.base.py.vm
    """

    def __init__(self):
        """
        Default constructor for this record.
        """
        self._id: str = None

    @classmethod
    def from_dict(cls, dict_obj: Dict[str, Any]):
        """
        Creates a record with the given dictionary's data.
        """
        record = cls()
        if dict_obj is not None:
            record.id = dict_obj.get("id")

        return record

    def as_dict(self) -> Dict[str, Any]:
        """
        Returns this record as a dictionary.
        """
        dict_obj = dict()

        dict_obj["id"] = self.id

        return dict_obj

    @classmethod
    def from_json(cls, json_str: str):
        """
        Creates a record with the given json string's data.
        """
        dict_obj = jsonpickle.decode(json_str)
        return cls.from_dict(dict_obj)

    def as_json(self) -> str:
        """
        Returns this record as a json string.
        """
        return jsonpickle.encode(self.as_dict())

    @property
    def id(self) -> str:
        return self._id

    @id.setter
    def id(self, id: str) -> None:
        self._id = id

    def validate(self) -> None:
        """
        Performs the validation for this record.
        """
        pass

    def get_value_by_field(self, field: SimpleRecordField) -> any:
        """
        Returns the value of the given field for this record.
        """
        value = None
        if field == SimpleRecordField.ID:
            value = self.id

        return value
